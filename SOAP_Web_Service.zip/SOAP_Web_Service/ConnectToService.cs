﻿using System;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Xml;
using System.Net.Security;

namespace SOAP_Web_Service
{
    public class ConnectToService
    {
        Logger logger = new Logger();
        
        public string InvokeService(string WSDLUri, string inputXMLFilePath, string clientCertificate, string outputFolderPath)
        {
            string[] paths1 = { outputFolderPath, "log.log" };
            string logFilePath = Path.Combine(paths1);
            string[] paths2 = { outputFolderPath, "output.xml" };
            string outputXMLPath = Path.Combine(paths2);
            try
            {
                if (Directory.Exists(outputFolderPath))
                {
                    //  string logFilePath = @"E:\SOAPOutput\log.log"; //outputFolderPath + "/log.log";
                    // string outputXMLPath = outputFolderPath; //outputFolderPath + "/output.xml";
                    logger.Debug("Creating SOAP Web Request with URI :" + WSDLUri, logFilePath);
                    //Calling CreateSOAPWebRequest method  
                    HttpWebRequest request = CreateSOAPWebRequest(WSDLUri, clientCertificate, logFilePath);
                    logger.Debug("Adding input XML with the request :" + WSDLUri, logFilePath);

                    string inputRawData = System.IO.File.ReadAllText(inputXMLFilePath);
                    XmlDocument SOAPReqBody = new XmlDocument();
                    //SOAP Body Request  
                    SOAPReqBody.LoadXml(inputRawData);
                    using (Stream stream = request.GetRequestStream())
                    {
                        SOAPReqBody.Save(stream);
                    }
                    logger.Debug("Request Generated   :" + request.ToString(), logFilePath);

                    ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback
                    (
                       delegate { return true; }
                    );

                    logger.Debug("Geting response from request........", logFilePath);

                    //Geting response from request  
                    using (WebResponse Serviceres = request.GetResponse())
                    {
                        using (StreamReader rd = new StreamReader(Serviceres.GetResponseStream()))
                        {
                            //reading stream  
                            var ServiceResult = rd.ReadToEnd();
                            //writting stream result on console  
                            Console.WriteLine(ServiceResult);
                            //   Console.ReadLine();
                            //Create the XmlDocument.  
                            XmlDocument doc = new XmlDocument();
                            doc.LoadXml(ServiceResult);
                            //Save the document to a file.  
                            logger.Debug("Response writing into   :" + outputXMLPath, logFilePath);
                            doc.Save(outputXMLPath);
                            return ServiceResult;
                        }
                    }
                }
                else
                {
                    logger.Debug(outputFolderPath + "folder doesn't exist", logFilePath);
                    return outputFolderPath + " folder doesn't exist";
                }
                  
            }
            catch (System.IO.IOException e)
            {
                logger.Error(e.Message, logFilePath);

                return e.Message;
            }
            catch (Exception e)
            {
                logger.Error(e.Message, logFilePath);
                return e.Message;
            }
            finally
            {

            }

        }

        public HttpWebRequest CreateSOAPWebRequest(string WSDLUri, string clientCertificate, string logFilePath)
        {
            //Making Web Request  
                 logger.Debug("Adding Certificate :" + clientCertificate, logFilePath);
                 X509Certificate2Collection certificates = new X509Certificate2Collection();
                //certificates.Import(certName, password, X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet);
                 certificates.Import(clientCertificate);
                


               HttpWebRequest Req = (HttpWebRequest)WebRequest.Create(WSDLUri);
                Req.AllowAutoRedirect = true;
                Req.ClientCertificates = certificates;

                //SOAPAction  
               //  Req.Headers.Add(@"SOAPAction:http://tempuri.org/MessageSplitterRequest");
                //Content_type  
                Req.ContentType = "text/xml;charset=\"utf-8\"";
                Req.Accept = "text/xml";
                //HTTP method  
                Req.Method = "POST";
               //return HttpWebRequest  

         
             return Req;
           

        }
    }
}
