﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SOAP_Web_Service
{
    class Logger
    {
        public void Debug(string logMessage,string logFilePath)
        {
            using (StreamWriter w = File.AppendText(logFilePath))
            {
                w.Write("DEBUG : ");
                w.WriteLine($"{DateTime.Now}  :{logMessage}");
            }
        }

        public void Error(string logMessage, string logFilePath)
        {
            using (StreamWriter w = File.AppendText(logFilePath))
            {
                w.Write("ERROR : ");
                w.WriteLine($"{DateTime.Now}  :{logMessage}");
            }
        }
    }
}
